<?php

/* PanelBundle:panel:singin.html.twig */
class __TwigTemplate_13205d46dd2aac5c2e837a92e0c0163f2cfa7a6cd38e0f98ab8425aa96014aa7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "PanelBundle:panel:singin.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_446a6e64cedf3713d053f28e21f84480e5cc40f9a387311def6acda5b7d2a2e9 = $this->env->getExtension("native_profiler");
        $__internal_446a6e64cedf3713d053f28e21f84480e5cc40f9a387311def6acda5b7d2a2e9->enter($__internal_446a6e64cedf3713d053f28e21f84480e5cc40f9a387311def6acda5b7d2a2e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PanelBundle:panel:singin.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_446a6e64cedf3713d053f28e21f84480e5cc40f9a387311def6acda5b7d2a2e9->leave($__internal_446a6e64cedf3713d053f28e21f84480e5cc40f9a387311def6acda5b7d2a2e9_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_06cb84d512f3ff864e379dd062a250575c354283f94c9a4bcfb9659bd3bf3887 = $this->env->getExtension("native_profiler");
        $__internal_06cb84d512f3ff864e379dd062a250575c354283f94c9a4bcfb9659bd3bf3887->enter($__internal_06cb84d512f3ff864e379dd062a250575c354283f94c9a4bcfb9659bd3bf3887_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/panel/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
    <link href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/panel/css/singin.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
";
        
        $__internal_06cb84d512f3ff864e379dd062a250575c354283f94c9a4bcfb9659bd3bf3887->leave($__internal_06cb84d512f3ff864e379dd062a250575c354283f94c9a4bcfb9659bd3bf3887_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_bf680de55e66a89332aae12ef8c4d500eb574f35ffaa20a9fd19d5d7df9356a1 = $this->env->getExtension("native_profiler");
        $__internal_bf680de55e66a89332aae12ef8c4d500eb574f35ffaa20a9fd19d5d7df9356a1->enter($__internal_bf680de55e66a89332aae12ef8c4d500eb574f35ffaa20a9fd19d5d7df9356a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "get", array(0 => "error"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 10
            echo "        <div class=\"alert alert-danger alert-dismissible\" role=\"alert\">
            <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
            <strong>Error!</strong> ";
            // line 12
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 15
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "get", array(0 => "success"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 16
            echo "        <div class=\"alert alert-success alert-dismissible\" role=\"alert\">
            <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
            <strong>Correcto!</strong> ";
            // line 18
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 21
        echo "    <div class=\"esp-60\"></div>
    <div class=\"col-sm-offset-3 col-sm-6\">
            ";
        // line 23
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        <p>
            ";
        // line 25
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "email", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Ingrese su Email.")));
        echo "
        </p>
        <p>
            ";
        // line 28
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "pass", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Ingrese su Contraseña.")));
        echo "
        </p>
        <p>
            ";
        // line 31
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "submit", array()), 'widget', array("attr" => array("class" => "btn btn-success", "value" => "Ingresar")));
        echo "
        </p>
            ";
        // line 33
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
    </div>
";
        
        $__internal_bf680de55e66a89332aae12ef8c4d500eb574f35ffaa20a9fd19d5d7df9356a1->leave($__internal_bf680de55e66a89332aae12ef8c4d500eb574f35ffaa20a9fd19d5d7df9356a1_prof);

    }

    // line 37
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_bbe92170f5e80b89a986c54f9bba317b31358a6d1ed0349f68aac3b1f907539e = $this->env->getExtension("native_profiler");
        $__internal_bbe92170f5e80b89a986c54f9bba317b31358a6d1ed0349f68aac3b1f907539e->enter($__internal_bbe92170f5e80b89a986c54f9bba317b31358a6d1ed0349f68aac3b1f907539e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 38
        echo "    <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/panel/js/jquery-1.11.3.min.js"), "html", null, true);
        echo "\" ></script>
    <script type=\"text/javascript\" src=\"";
        // line 39
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/panel/js/bootstrap.min.js"), "html", null, true);
        echo "\" ></script>
";
        
        $__internal_bbe92170f5e80b89a986c54f9bba317b31358a6d1ed0349f68aac3b1f907539e->leave($__internal_bbe92170f5e80b89a986c54f9bba317b31358a6d1ed0349f68aac3b1f907539e_prof);

    }

    public function getTemplateName()
    {
        return "PanelBundle:panel:singin.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  145 => 39,  140 => 38,  134 => 37,  124 => 33,  119 => 31,  113 => 28,  107 => 25,  102 => 23,  98 => 21,  89 => 18,  85 => 16,  80 => 15,  71 => 12,  67 => 10,  62 => 9,  56 => 8,  47 => 5,  42 => 4,  36 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block stylesheets %}*/
/*     <link href="{{ asset('bundles/panel/css/bootstrap.min.css') }}" rel="stylesheet" />*/
/*     <link href="{{ asset('bundles/panel/css/singin.css') }}" rel="stylesheet" />*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/*     {% for flashMessage in app.session.flashBag.get('error') %}*/
/*         <div class="alert alert-danger alert-dismissible" role="alert">*/
/*             <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>*/
/*             <strong>Error!</strong> {{ flashMessage }}*/
/*         </div>*/
/*     {% endfor %}*/
/*     {% for flashMessage in app.session.flashBag.get('success') %}*/
/*         <div class="alert alert-success alert-dismissible" role="alert">*/
/*             <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>*/
/*             <strong>Correcto!</strong> {{ flashMessage }}*/
/*         </div>*/
/*     {% endfor %}*/
/*     <div class="esp-60"></div>*/
/*     <div class="col-sm-offset-3 col-sm-6">*/
/*             {{ form_start(form) }}*/
/*         <p>*/
/*             {{ form_widget(form.email, { 'attr': { 'class': 'form-control', 'placeholder': 'Ingrese su Email.' } }) }}*/
/*         </p>*/
/*         <p>*/
/*             {{ form_widget(form.pass, { 'attr': { 'class': 'form-control', 'placeholder': 'Ingrese su Contraseña.' } }) }}*/
/*         </p>*/
/*         <p>*/
/*             {{ form_widget(form.submit, { 'attr': { 'class': 'btn btn-success', 'value': 'Ingresar' } }) }}*/
/*         </p>*/
/*             {{ form_end(form) }}*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block scripts %}*/
/*     <script type="text/javascript" src="{{ asset('bundles/panel/js/jquery-1.11.3.min.js') }}" ></script>*/
/*     <script type="text/javascript" src="{{ asset('bundles/panel/js/bootstrap.min.js') }}" ></script>*/
/* {% endblock %}*/
