<?php

/* PanelBundle:panel:singin.html.twig */
class __TwigTemplate_13205d46dd2aac5c2e837a92e0c0163f2cfa7a6cd38e0f98ab8425aa96014aa7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "PanelBundle:panel:singin.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6a3a99a00edff2e4041ebd1d6d414867fe7f2662ced8f2be22ef23da58e9b21d = $this->env->getExtension("native_profiler");
        $__internal_6a3a99a00edff2e4041ebd1d6d414867fe7f2662ced8f2be22ef23da58e9b21d->enter($__internal_6a3a99a00edff2e4041ebd1d6d414867fe7f2662ced8f2be22ef23da58e9b21d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PanelBundle:panel:singin.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6a3a99a00edff2e4041ebd1d6d414867fe7f2662ced8f2be22ef23da58e9b21d->leave($__internal_6a3a99a00edff2e4041ebd1d6d414867fe7f2662ced8f2be22ef23da58e9b21d_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_73096def47cb16401ef0eb06231bd18a25fc02dabf037c4f7a48b0341a85b37b = $this->env->getExtension("native_profiler");
        $__internal_73096def47cb16401ef0eb06231bd18a25fc02dabf037c4f7a48b0341a85b37b->enter($__internal_73096def47cb16401ef0eb06231bd18a25fc02dabf037c4f7a48b0341a85b37b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    ";
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
    ";
        // line 5
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

    ";
        // line 7
        if (array_key_exists("pass", $context)) {
            // line 8
            echo "        ";
            echo twig_escape_filter($this->env, (isset($context["pass"]) ? $context["pass"] : $this->getContext($context, "pass")), "html", null, true);
            echo "
    ";
        }
        
        $__internal_73096def47cb16401ef0eb06231bd18a25fc02dabf037c4f7a48b0341a85b37b->leave($__internal_73096def47cb16401ef0eb06231bd18a25fc02dabf037c4f7a48b0341a85b37b_prof);

    }

    public function getTemplateName()
    {
        return "PanelBundle:panel:singin.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  52 => 8,  50 => 7,  45 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/*     {{ form_start(form) }}*/
/*     {{ form_end(form) }}*/
/* */
/*     {% if pass is defined %}*/
/*         {{ pass }}*/
/*     {% endif %}*/
/* {% endblock %}*/
