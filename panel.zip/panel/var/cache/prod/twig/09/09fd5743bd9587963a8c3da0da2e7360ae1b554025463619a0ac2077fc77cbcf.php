<?php

/* PanelBundle:panel:base.html.twig */
class __TwigTemplate_1b846701e27d0092ec594f74a200ad3c5671036ce0bb4d7e219f1f6724e63caa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'metas' => array($this, 'block_metas'),
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5202442aed39725026e8f7eaab38d09d781540002ae62f8f2eaf410ae315a081 = $this->env->getExtension("native_profiler");
        $__internal_5202442aed39725026e8f7eaab38d09d781540002ae62f8f2eaf410ae315a081->enter($__internal_5202442aed39725026e8f7eaab38d09d781540002ae62f8f2eaf410ae315a081_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PanelBundle:panel:base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"es\">
    <head>
        <meta charset=\"UTF-8\" />
        <meta http-equiv=\"Content-Language\" content=\"es\"/>
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
        ";
        // line 7
        $this->displayBlock('metas', $context, $blocks);
        // line 8
        echo "        <meta name=\"author\" content=\"Frank\">
        <title>";
        // line 9
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 10
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 11
        echo "        
      
    </head>
    <body>
<<<<<<< HEAD
        ";
        // line 16
        echo twig_include($this->env, $context, "PanelBundle:panel:header.html.twig");
        echo "
=======
       
>>>>>>> 3f02395f1593a521ab57baa9f16f9393a4db7b53
        ";
        // line 20
        $this->displayBlock('body', $context, $blocks);
        // line 21
        echo "        ";
        $this->displayBlock('scripts', $context, $blocks);
        // line 22
        echo "
    </body>
</html>
";
        
        $__internal_5202442aed39725026e8f7eaab38d09d781540002ae62f8f2eaf410ae315a081->leave($__internal_5202442aed39725026e8f7eaab38d09d781540002ae62f8f2eaf410ae315a081_prof);

    }

    // line 7
    public function block_metas($context, array $blocks = array())
    {
        $__internal_e093ad2e3e76f61e7cd126ef2ec8ecf3b3730859d261a32ba1db3459bf00f48f = $this->env->getExtension("native_profiler");
        $__internal_e093ad2e3e76f61e7cd126ef2ec8ecf3b3730859d261a32ba1db3459bf00f48f->enter($__internal_e093ad2e3e76f61e7cd126ef2ec8ecf3b3730859d261a32ba1db3459bf00f48f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "metas"));

        
        $__internal_e093ad2e3e76f61e7cd126ef2ec8ecf3b3730859d261a32ba1db3459bf00f48f->leave($__internal_e093ad2e3e76f61e7cd126ef2ec8ecf3b3730859d261a32ba1db3459bf00f48f_prof);

    }

    // line 9
    public function block_title($context, array $blocks = array())
    {
        $__internal_0bb2c3419c69afad8d172b85e2f11246c8459912ae3e22a33fb48508a8c63d90 = $this->env->getExtension("native_profiler");
        $__internal_0bb2c3419c69afad8d172b85e2f11246c8459912ae3e22a33fb48508a8c63d90->enter($__internal_0bb2c3419c69afad8d172b85e2f11246c8459912ae3e22a33fb48508a8c63d90_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_0bb2c3419c69afad8d172b85e2f11246c8459912ae3e22a33fb48508a8c63d90->leave($__internal_0bb2c3419c69afad8d172b85e2f11246c8459912ae3e22a33fb48508a8c63d90_prof);

    }

    // line 10
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_569f6066d703df09927188cb4d100232a595cd75ca4eb25425b7c468cf725af1 = $this->env->getExtension("native_profiler");
        $__internal_569f6066d703df09927188cb4d100232a595cd75ca4eb25425b7c468cf725af1->enter($__internal_569f6066d703df09927188cb4d100232a595cd75ca4eb25425b7c468cf725af1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_569f6066d703df09927188cb4d100232a595cd75ca4eb25425b7c468cf725af1->leave($__internal_569f6066d703df09927188cb4d100232a595cd75ca4eb25425b7c468cf725af1_prof);

    }

    // line 20
    public function block_body($context, array $blocks = array())
    {
        $__internal_4aef3df0f0992fd3fe6ffe95f0b8e231f97ffbc357191acc07b2e72bd9866f60 = $this->env->getExtension("native_profiler");
        $__internal_4aef3df0f0992fd3fe6ffe95f0b8e231f97ffbc357191acc07b2e72bd9866f60->enter($__internal_4aef3df0f0992fd3fe6ffe95f0b8e231f97ffbc357191acc07b2e72bd9866f60_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_4aef3df0f0992fd3fe6ffe95f0b8e231f97ffbc357191acc07b2e72bd9866f60->leave($__internal_4aef3df0f0992fd3fe6ffe95f0b8e231f97ffbc357191acc07b2e72bd9866f60_prof);

    }

    // line 21
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_a1d41b0cdb6c653bafae01f8a0a24345ef9b6e42fe9a8c94cbdb8182c3e8951f = $this->env->getExtension("native_profiler");
        $__internal_a1d41b0cdb6c653bafae01f8a0a24345ef9b6e42fe9a8c94cbdb8182c3e8951f->enter($__internal_a1d41b0cdb6c653bafae01f8a0a24345ef9b6e42fe9a8c94cbdb8182c3e8951f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        
        $__internal_a1d41b0cdb6c653bafae01f8a0a24345ef9b6e42fe9a8c94cbdb8182c3e8951f->leave($__internal_a1d41b0cdb6c653bafae01f8a0a24345ef9b6e42fe9a8c94cbdb8182c3e8951f_prof);

    }

    public function getTemplateName()
    {
        return "PanelBundle:panel:base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  119 => 21,  108 => 20,  97 => 10,  86 => 9,  75 => 7,  65 => 22,  62 => 21,  60 => 20,  53 => 16,  46 => 11,  44 => 10,  40 => 9,  37 => 8,  35 => 7,  27 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html lang="es">*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <meta http-equiv="Content-Language" content="es"/>*/
/*         <meta name="viewport" content="width=device-width, initial-scale=1.0">*/
/*         {% block metas %}{% endblock %}*/
/*         <meta name="author" content="Frank">*/
/*         <title>{% block title %}{% endblock %}</title>*/
/*         {% block stylesheets %}{% endblock %}*/
/*         */
/*       */
/*     </head>*/
/*     <body>*/
/* <<<<<<< HEAD*/
/*         {{ include("PanelBundle:panel:header.html.twig") }}*/
/* =======*/
/*        */
/* >>>>>>> 3f02395f1593a521ab57baa9f16f9393a4db7b53*/
/*         {% block body %}{% endblock %}*/
/*         {% block scripts %}{% endblock %}*/
/* */
/*     </body>*/
/* </html>*/
/* */
