<?php

/* PanelBundle:panel:home.html.twig */
class __TwigTemplate_10696204a95506209146bace5367d87a894f76df8d4c8d2cd0e9c91870911721 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("PanelBundle:panel:base.html.twig", "PanelBundle:panel:home.html.twig", 1);
        $this->blocks = array(
            'metas' => array($this, 'block_metas'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "PanelBundle:panel:base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7e8f171b39c2672dd3d8591e88621ea9ad96d2a9dcaeff76d0eab9ace8e2a645 = $this->env->getExtension("native_profiler");
        $__internal_7e8f171b39c2672dd3d8591e88621ea9ad96d2a9dcaeff76d0eab9ace8e2a645->enter($__internal_7e8f171b39c2672dd3d8591e88621ea9ad96d2a9dcaeff76d0eab9ace8e2a645_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PanelBundle:panel:home.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7e8f171b39c2672dd3d8591e88621ea9ad96d2a9dcaeff76d0eab9ace8e2a645->leave($__internal_7e8f171b39c2672dd3d8591e88621ea9ad96d2a9dcaeff76d0eab9ace8e2a645_prof);

    }

    // line 3
    public function block_metas($context, array $blocks = array())
    {
        $__internal_3a73d97b2256a43ee44eb920750988faa9414ed257551010ba500113b847a004 = $this->env->getExtension("native_profiler");
        $__internal_3a73d97b2256a43ee44eb920750988faa9414ed257551010ba500113b847a004->enter($__internal_3a73d97b2256a43ee44eb920750988faa9414ed257551010ba500113b847a004_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "metas"));

        // line 4
        echo "<meta name=\"description\" content=\"panel excel\">
<meta name=\"keywords\" content=\"Panel\">
";
        
        $__internal_3a73d97b2256a43ee44eb920750988faa9414ed257551010ba500113b847a004->leave($__internal_3a73d97b2256a43ee44eb920750988faa9414ed257551010ba500113b847a004_prof);

    }

    // line 8
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_af8fc7ced4585ff8e5165903bc4b122b9a97406b2d70bb18befc2780c43698e3 = $this->env->getExtension("native_profiler");
        $__internal_af8fc7ced4585ff8e5165903bc4b122b9a97406b2d70bb18befc2780c43698e3->enter($__internal_af8fc7ced4585ff8e5165903bc4b122b9a97406b2d70bb18befc2780c43698e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 9
        echo "\t
\t<link href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/panel/css/styles.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
";
        
        $__internal_af8fc7ced4585ff8e5165903bc4b122b9a97406b2d70bb18befc2780c43698e3->leave($__internal_af8fc7ced4585ff8e5165903bc4b122b9a97406b2d70bb18befc2780c43698e3_prof);

    }

    // line 14
    public function block_body($context, array $blocks = array())
    {
        $__internal_83337504243732d4b46c824591543d05bf56c906b676e2c73be4428a78a66ab9 = $this->env->getExtension("native_profiler");
        $__internal_83337504243732d4b46c824591543d05bf56c906b676e2c73be4428a78a66ab9->enter($__internal_83337504243732d4b46c824591543d05bf56c906b676e2c73be4428a78a66ab9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 15
        echo "\t";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "get", array(0 => "rol"), "method"), "html", null, true);
        echo "
<div class=\"conte90 margin-top-first-content\">
<center><img class=\"banerhome\" src=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/panel/images/banerHomeExcel.png"), "html", null, true);
        echo "\" /></center>
";
        // line 18
        if (((isset($context["numerofilas"]) ? $context["numerofilas"] : $this->getContext($context, "numerofilas")) != "")) {
            // line 19
            echo "\t";
            echo (isset($context["numerofilas"]) ? $context["numerofilas"] : $this->getContext($context, "numerofilas"));
            echo "
";
        }
        // line 21
        echo "
<!-- form1 -->
";
        // line 23
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("id" => "form-seleccionar")));
        echo "
";
        // line 24
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
";
        // line 25
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
<!-- END form1 -->

</div>
";
        
        $__internal_83337504243732d4b46c824591543d05bf56c906b676e2c73be4428a78a66ab9->leave($__internal_83337504243732d4b46c824591543d05bf56c906b676e2c73be4428a78a66ab9_prof);

    }

    // line 31
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_579c400ef3d5a399b16481401ed7d7d6e7e898d07f4c9ca01c93242fc78b2145 = $this->env->getExtension("native_profiler");
        $__internal_579c400ef3d5a399b16481401ed7d7d6e7e898d07f4c9ca01c93242fc78b2145->enter($__internal_579c400ef3d5a399b16481401ed7d7d6e7e898d07f4c9ca01c93242fc78b2145_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 32
        echo "<script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/panel/js/jquery-1.11.3.min.js"), "html", null, true);
        echo "\" ></script>
<script type=\"text/javascript\" src=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/panel/js/funciones.js"), "html", null, true);
        echo "\" ></script>
";
        
        $__internal_579c400ef3d5a399b16481401ed7d7d6e7e898d07f4c9ca01c93242fc78b2145->leave($__internal_579c400ef3d5a399b16481401ed7d7d6e7e898d07f4c9ca01c93242fc78b2145_prof);

    }

    public function getTemplateName()
    {
        return "PanelBundle:panel:home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  129 => 33,  124 => 32,  118 => 31,  106 => 25,  102 => 24,  98 => 23,  94 => 21,  88 => 19,  86 => 18,  82 => 17,  76 => 15,  70 => 14,  61 => 10,  58 => 9,  52 => 8,  43 => 4,  37 => 3,  11 => 1,);
    }
}
/* {% extends 'PanelBundle:panel:base.html.twig' %}*/
/* */
/* {% block metas %}*/
/* <meta name="description" content="panel excel">*/
/* <meta name="keywords" content="Panel">*/
/* {% endblock %}*/
/* */
/* {% block stylesheets %}*/
/* 	*/
/* 	<link href="{{ asset('bundles/panel/css/styles.css') }}" rel="stylesheet" />*/
/* {% endblock %}*/
/* */
/* */
/* {% block body %}*/
/* 	{{ app.session.get('rol') }}*/
/* <div class="conte90 margin-top-first-content">*/
/* <center><img class="banerhome" src="{{ asset('bundles/panel/images/banerHomeExcel.png') }}" /></center>*/
/* {% if numerofilas!= "" %}*/
/* 	{{ numerofilas|raw }}*/
/* {% endif %}*/
/* */
/* <!-- form1 -->*/
/* {{ form_start(form, {'attr': {'id': 'form-seleccionar'}})  }}*/
/* {{ form_widget(form) }}*/
/* {{ form_end(form) }}*/
/* <!-- END form1 -->*/
/* */
/* </div>*/
/* {% endblock %}*/
/* */
/* {% block scripts %}*/
/* <script type="text/javascript" src="{{ asset('bundles/panel/js/jquery-1.11.3.min.js') }}" ></script>*/
/* <script type="text/javascript" src="{{ asset('bundles/panel/js/funciones.js') }}" ></script>*/
/* {% endblock %}*/
/* */
/* */
/* */
/* */
/* */
