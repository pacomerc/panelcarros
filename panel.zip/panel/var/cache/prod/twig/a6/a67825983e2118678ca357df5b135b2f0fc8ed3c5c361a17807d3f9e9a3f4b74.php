<?php

/* PanelBundle:panel:home.html.twig */
class __TwigTemplate_10696204a95506209146bace5367d87a894f76df8d4c8d2cd0e9c91870911721 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("PanelBundle:panel:base.html.twig", "PanelBundle:panel:home.html.twig", 1);
        $this->blocks = array(
            'metas' => array($this, 'block_metas'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "PanelBundle:panel:base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b496379a85bf2d3d5e3581bd6e2e5f31b9573e3c5ecd778600ded6b7f24a8bcd = $this->env->getExtension("native_profiler");
        $__internal_b496379a85bf2d3d5e3581bd6e2e5f31b9573e3c5ecd778600ded6b7f24a8bcd->enter($__internal_b496379a85bf2d3d5e3581bd6e2e5f31b9573e3c5ecd778600ded6b7f24a8bcd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PanelBundle:panel:home.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b496379a85bf2d3d5e3581bd6e2e5f31b9573e3c5ecd778600ded6b7f24a8bcd->leave($__internal_b496379a85bf2d3d5e3581bd6e2e5f31b9573e3c5ecd778600ded6b7f24a8bcd_prof);

    }

    // line 3
    public function block_metas($context, array $blocks = array())
    {
        $__internal_8cff6341cc90e7904ca175af7bb79f22936b1317e90c0cbadb3802bce7b2d36b = $this->env->getExtension("native_profiler");
        $__internal_8cff6341cc90e7904ca175af7bb79f22936b1317e90c0cbadb3802bce7b2d36b->enter($__internal_8cff6341cc90e7904ca175af7bb79f22936b1317e90c0cbadb3802bce7b2d36b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "metas"));

        // line 4
        echo "<meta name=\"description\" content=\"panel excel\">
<meta name=\"keywords\" content=\"Panel\">
";
        
        $__internal_8cff6341cc90e7904ca175af7bb79f22936b1317e90c0cbadb3802bce7b2d36b->leave($__internal_8cff6341cc90e7904ca175af7bb79f22936b1317e90c0cbadb3802bce7b2d36b_prof);

    }

    // line 8
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_02c5cf9852804b0db45a7833ccc2f6ef70bb783de29cb258b3da997a56a50e04 = $this->env->getExtension("native_profiler");
        $__internal_02c5cf9852804b0db45a7833ccc2f6ef70bb783de29cb258b3da997a56a50e04->enter($__internal_02c5cf9852804b0db45a7833ccc2f6ef70bb783de29cb258b3da997a56a50e04_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 9
        echo "\t
\t<link href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/panel/css/styles.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
";
        
        $__internal_02c5cf9852804b0db45a7833ccc2f6ef70bb783de29cb258b3da997a56a50e04->leave($__internal_02c5cf9852804b0db45a7833ccc2f6ef70bb783de29cb258b3da997a56a50e04_prof);

    }

    // line 14
    public function block_body($context, array $blocks = array())
    {
        $__internal_1015fa48314b3b2b5ae9de8d18b925f47a4ff4fb5507ce6b2c36f381fa706577 = $this->env->getExtension("native_profiler");
        $__internal_1015fa48314b3b2b5ae9de8d18b925f47a4ff4fb5507ce6b2c36f381fa706577->enter($__internal_1015fa48314b3b2b5ae9de8d18b925f47a4ff4fb5507ce6b2c36f381fa706577_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 15
        echo "<div class=\"conte90 margin-top-first-content\">
<center><img class=\"banerhome\" src=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/panel/images/banerHomeExcel.png"), "html", null, true);
        echo "\" /></center>
";
        // line 17
        if (((isset($context["numerofilas"]) ? $context["numerofilas"] : $this->getContext($context, "numerofilas")) != "")) {
            // line 18
            echo "\t";
            echo (isset($context["numerofilas"]) ? $context["numerofilas"] : $this->getContext($context, "numerofilas"));
            echo "
";
        }
        // line 20
        echo "
<!-- form1 -->
";
        // line 22
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("id" => "form-seleccionar")));
        echo "
";
        // line 23
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
";
        // line 24
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
<!-- END form1 -->

</div>
";
        
        $__internal_1015fa48314b3b2b5ae9de8d18b925f47a4ff4fb5507ce6b2c36f381fa706577->leave($__internal_1015fa48314b3b2b5ae9de8d18b925f47a4ff4fb5507ce6b2c36f381fa706577_prof);

    }

    // line 30
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_4a8c531ec531f10933433a2bed09fe5c73b1737dcfa1327ddcbec0f0a669ff86 = $this->env->getExtension("native_profiler");
        $__internal_4a8c531ec531f10933433a2bed09fe5c73b1737dcfa1327ddcbec0f0a669ff86->enter($__internal_4a8c531ec531f10933433a2bed09fe5c73b1737dcfa1327ddcbec0f0a669ff86_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 31
        echo "<script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/panel/js/jquery-2.1.4.min.js"), "html", null, true);
        echo "\" ></script>
<script type=\"text/javascript\" src=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/panel/js/funciones.js"), "html", null, true);
        echo "\" ></script>
";
        
        $__internal_4a8c531ec531f10933433a2bed09fe5c73b1737dcfa1327ddcbec0f0a669ff86->leave($__internal_4a8c531ec531f10933433a2bed09fe5c73b1737dcfa1327ddcbec0f0a669ff86_prof);

    }

    public function getTemplateName()
    {
        return "PanelBundle:panel:home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  126 => 32,  121 => 31,  115 => 30,  103 => 24,  99 => 23,  95 => 22,  91 => 20,  85 => 18,  83 => 17,  79 => 16,  76 => 15,  70 => 14,  61 => 10,  58 => 9,  52 => 8,  43 => 4,  37 => 3,  11 => 1,);
    }
}
/* {% extends 'PanelBundle:panel:base.html.twig' %}*/
/* */
/* {% block metas %}*/
/* <meta name="description" content="panel excel">*/
/* <meta name="keywords" content="Panel">*/
/* {% endblock %}*/
/* */
/* {% block stylesheets %}*/
/* 	*/
/* 	<link href="{{ asset('bundles/panel/css/styles.css') }}" rel="stylesheet" />*/
/* {% endblock %}*/
/* */
/* */
/* {% block body %}*/
/* <div class="conte90 margin-top-first-content">*/
/* <center><img class="banerhome" src="{{ asset('bundles/panel/images/banerHomeExcel.png') }}" /></center>*/
/* {% if numerofilas!= "" %}*/
/* 	{{ numerofilas|raw }}*/
/* {% endif %}*/
/* */
/* <!-- form1 -->*/
/* {{ form_start(form, {'attr': {'id': 'form-seleccionar'}})  }}*/
/* {{ form_widget(form) }}*/
/* {{ form_end(form) }}*/
/* <!-- END form1 -->*/
/* */
/* </div>*/
/* {% endblock %}*/
/* */
/* {% block scripts %}*/
/* <script type="text/javascript" src="{{ asset('bundles/panel/js/jquery-2.1.4.min.js') }}" ></script>*/
/* <script type="text/javascript" src="{{ asset('bundles/panel/js/funciones.js') }}" ></script>*/
/* {% endblock %}*/
/* */
/* */
/* */
/* */
/* */
