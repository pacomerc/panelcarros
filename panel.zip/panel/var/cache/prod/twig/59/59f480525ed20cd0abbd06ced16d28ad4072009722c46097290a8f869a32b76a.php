<?php

/* PanelBundle:panel:header.html.twig */
class __TwigTemplate_628526d065c2d4406ab951f670adef9df1799dec7641030044f8c58731288fb3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'header' => array($this, 'block_header'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4277754991e0facbe3c961ed3ce6ea805135e5e0f2f898266d0e2dff3f3e46a9 = $this->env->getExtension("native_profiler");
        $__internal_4277754991e0facbe3c961ed3ce6ea805135e5e0f2f898266d0e2dff3f3e46a9->enter($__internal_4277754991e0facbe3c961ed3ce6ea805135e5e0f2f898266d0e2dff3f3e46a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PanelBundle:panel:header.html.twig"));

        // line 1
        $this->displayBlock('header', $context, $blocks);
        
        $__internal_4277754991e0facbe3c961ed3ce6ea805135e5e0f2f898266d0e2dff3f3e46a9->leave($__internal_4277754991e0facbe3c961ed3ce6ea805135e5e0f2f898266d0e2dff3f3e46a9_prof);

    }

    public function block_header($context, array $blocks = array())
    {
        $__internal_0f3188473b8c9dae910ebd57e7b062d5b505e969a4b06e31fbed6d420ac5f94e = $this->env->getExtension("native_profiler");
        $__internal_0f3188473b8c9dae910ebd57e7b062d5b505e969a4b06e31fbed6d420ac5f94e->enter($__internal_0f3188473b8c9dae910ebd57e7b062d5b505e969a4b06e31fbed6d420ac5f94e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 2
        echo "<header>
\t<div class=\"header-top\">
\t\t<ul class=\"colHeader\">
\t\t\t<li>
\t\t\t\t<div class=\"conteMenu\"><span><img src=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/panel/images/btnMenul.png"), "html", null, true);
        echo "\"></span>Menu</div>
\t\t\t</li>
\t\t\t<li><a href=\"#\" class=\"logo\"><img src=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/panel/images/logo.png"), "html", null, true);
        echo "\"></a></li>
\t\t\t<li></li>
\t\t\t<div class=\"clear\"></div>
\t\t</ul>
\t</div>
\t<div class=\"header-bot\">
\t\t<ul class=\"colHeaderBot\">
\t\t\t<li>Sales: 800-417-5660\tService: 800-417-5731</li>
\t\t\t<li>3300 Jamboree Road • Newport Beach, CA 92660</li>
\t\t\t<div class=\"clear\"></div>
\t\t</ul>
\t</div>
</header>
<div class=\"menuLateral\" style=\"top: -100%;\">
\t<div class=\"cerrarMenu\">
\t\t<div class=\"padding\">
\t\t\t<i class=\"fa fa-times\" aria-hidden=\"true\"></i><span>Cerrar</span>
\t\t</div>
\t</div>
\t<ul class=\"menu\">
\t\t<li class=\"menu_activo\"><a href=\"inicio\">inicio</a></li>
\t\t<li>
\t\t\t<a href=\"autos\">autos</a>
\t\t\t<ul class=\"submenu\">
\t\t\t\t<li><a href=\"autos-nuevos\">buscar nuevos</a></li>
\t\t\t\t<li><a href=\"autos-usados\">buscar usados</a></li>
\t\t\t\t<li><a href=\"javascript:void(0);\">cotizar rápido</a></li>
\t\t\t</ul>
\t\t</li>
\t\t<li>
\t\t\t<a href=\"javascript:void();\">ofertas</a>
\t\t\t<ul class=\"submenu\">
\t\t\t\t<li><a href=\"javascript:void(0);\">de autos nuevos</a></li>
\t\t\t\t<li><a href=\"javascript:void(0);\">de autos usados</a></li>
\t\t\t\t<li><a href=\"oferta-servicios\">de servicios</a></li>
\t\t\t</ul>
\t\t</li>
\t\t<li>
\t\t\t<a href=\"javascript:void();\">finanzas</a>
\t\t\t<ul class=\"submenu\">
\t\t\t\t<li><a href=\"financiamiento\">financiamiento</a></li>
\t\t\t\t<li><a href=\"comprar-arrendar\">comprar o arrendar</a></li>
\t\t\t</ul>
\t\t</li>
\t\t<li>
\t\t\t<a href=\"javascript:void();\">devolución</a>
\t\t\t<ul class=\"submenu\">
\t\t\t\t<li><a href=\"centro-entrega\">centro de entrega de arrendamientos</a></li>
\t\t\t</ul>
\t\t</li>
\t\t<li>
\t\t\t<a href=\"javascript:void();\">servicio y partes</a>
\t\t\t<ul class=\"submenu\">
\t\t\t\t<li><a href=\"solicitud-servicio\">solicitud de servicio</a></li>
\t\t\t\t<li><a href=\"almacen-llantas\">almacén de llantas</a></li>
\t\t\t\t<li><a href=\"solicitud-refacciones\">solicitud de refacciones</a></li>
\t\t\t\t<li><a href=\"accesorios\">accesorios</a></li>
\t\t\t\t<li><a href=\"oferta-servicios\">ofertas de servicios</a></li>
\t\t\t\t<li><a href=\"cambio-aceite\">cambio de aceite</a></li>
\t\t\t\t<li><a href=\"centro-llantas\">centro de llantas</a></li>
\t\t\t\t<li><a href=\"encuenta-servicio\">encuesta de servicio</a></li>
\t\t\t\t<li><a href=\"http://ca243.kiaaccessoryguide.com/\" target=\"_blank\">accesorios KIA</a></li>
\t\t\t\t<li><a href=\"menus-mantenimiento\">menús de mantenimiento</a></li>
\t\t\t\t<li><a href=\"sobre-servicio\">sobres el servicio</a></li>
\t\t\t</ul>
\t\t</li>
\t\t<li>
\t\t\t<a href=\"javascript:void();\">nosotros</a>
\t\t\t<ul class=\"submenu\">
\t\t\t\t<li><a href=\"direccion-horarios\">dirección y horarios</a></li>
\t\t\t\t<li><a href=\"contactenos\">contáctenos</a></li>
\t\t\t\t<li><a href=\"encuesta-citio\">encuesta del citio web</a></li>
\t\t\t\t<li><a href=\"videos-kia\">videos kia</a></li>
\t\t\t\t<li><a href=\"garantia-kia\">garantia kia</a></li>
\t\t\t\t<li><a href=\"comentarios-clientes\">comentarios de clientes</a></li>
\t\t\t\t<li><a href=\"blog\">blog</a></li>
\t\t\t</ul>
\t\t</li>
\t</ul>
</div>
";
        
        $__internal_0f3188473b8c9dae910ebd57e7b062d5b505e969a4b06e31fbed6d420ac5f94e->leave($__internal_0f3188473b8c9dae910ebd57e7b062d5b505e969a4b06e31fbed6d420ac5f94e_prof);

    }

    public function getTemplateName()
    {
        return "PanelBundle:panel:header.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  46 => 8,  41 => 6,  35 => 2,  23 => 1,);
    }
}
/* {% block header %}*/
/* <header>*/
/* 	<div class="header-top">*/
/* 		<ul class="colHeader">*/
/* 			<li>*/
/* 				<div class="conteMenu"><span><img src="{{ asset('bundles/panel/images/btnMenul.png') }}"></span>Menu</div>*/
/* 			</li>*/
/* 			<li><a href="#" class="logo"><img src="{{ asset('bundles/panel/images/logo.png') }}"></a></li>*/
/* 			<li></li>*/
/* 			<div class="clear"></div>*/
/* 		</ul>*/
/* 	</div>*/
/* 	<div class="header-bot">*/
/* 		<ul class="colHeaderBot">*/
/* 			<li>Sales: 800-417-5660	Service: 800-417-5731</li>*/
/* 			<li>3300 Jamboree Road • Newport Beach, CA 92660</li>*/
/* 			<div class="clear"></div>*/
/* 		</ul>*/
/* 	</div>*/
/* </header>*/
/* <div class="menuLateral" style="top: -100%;">*/
/* 	<div class="cerrarMenu">*/
/* 		<div class="padding">*/
/* 			<i class="fa fa-times" aria-hidden="true"></i><span>Cerrar</span>*/
/* 		</div>*/
/* 	</div>*/
/* 	<ul class="menu">*/
/* 		<li class="menu_activo"><a href="inicio">inicio</a></li>*/
/* 		<li>*/
/* 			<a href="autos">autos</a>*/
/* 			<ul class="submenu">*/
/* 				<li><a href="autos-nuevos">buscar nuevos</a></li>*/
/* 				<li><a href="autos-usados">buscar usados</a></li>*/
/* 				<li><a href="javascript:void(0);">cotizar rápido</a></li>*/
/* 			</ul>*/
/* 		</li>*/
/* 		<li>*/
/* 			<a href="javascript:void();">ofertas</a>*/
/* 			<ul class="submenu">*/
/* 				<li><a href="javascript:void(0);">de autos nuevos</a></li>*/
/* 				<li><a href="javascript:void(0);">de autos usados</a></li>*/
/* 				<li><a href="oferta-servicios">de servicios</a></li>*/
/* 			</ul>*/
/* 		</li>*/
/* 		<li>*/
/* 			<a href="javascript:void();">finanzas</a>*/
/* 			<ul class="submenu">*/
/* 				<li><a href="financiamiento">financiamiento</a></li>*/
/* 				<li><a href="comprar-arrendar">comprar o arrendar</a></li>*/
/* 			</ul>*/
/* 		</li>*/
/* 		<li>*/
/* 			<a href="javascript:void();">devolución</a>*/
/* 			<ul class="submenu">*/
/* 				<li><a href="centro-entrega">centro de entrega de arrendamientos</a></li>*/
/* 			</ul>*/
/* 		</li>*/
/* 		<li>*/
/* 			<a href="javascript:void();">servicio y partes</a>*/
/* 			<ul class="submenu">*/
/* 				<li><a href="solicitud-servicio">solicitud de servicio</a></li>*/
/* 				<li><a href="almacen-llantas">almacén de llantas</a></li>*/
/* 				<li><a href="solicitud-refacciones">solicitud de refacciones</a></li>*/
/* 				<li><a href="accesorios">accesorios</a></li>*/
/* 				<li><a href="oferta-servicios">ofertas de servicios</a></li>*/
/* 				<li><a href="cambio-aceite">cambio de aceite</a></li>*/
/* 				<li><a href="centro-llantas">centro de llantas</a></li>*/
/* 				<li><a href="encuenta-servicio">encuesta de servicio</a></li>*/
/* 				<li><a href="http://ca243.kiaaccessoryguide.com/" target="_blank">accesorios KIA</a></li>*/
/* 				<li><a href="menus-mantenimiento">menús de mantenimiento</a></li>*/
/* 				<li><a href="sobre-servicio">sobres el servicio</a></li>*/
/* 			</ul>*/
/* 		</li>*/
/* 		<li>*/
/* 			<a href="javascript:void();">nosotros</a>*/
/* 			<ul class="submenu">*/
/* 				<li><a href="direccion-horarios">dirección y horarios</a></li>*/
/* 				<li><a href="contactenos">contáctenos</a></li>*/
/* 				<li><a href="encuesta-citio">encuesta del citio web</a></li>*/
/* 				<li><a href="videos-kia">videos kia</a></li>*/
/* 				<li><a href="garantia-kia">garantia kia</a></li>*/
/* 				<li><a href="comentarios-clientes">comentarios de clientes</a></li>*/
/* 				<li><a href="blog">blog</a></li>*/
/* 			</ul>*/
/* 		</li>*/
/* 	</ul>*/
/* </div>*/
/* {% endblock%}*/
