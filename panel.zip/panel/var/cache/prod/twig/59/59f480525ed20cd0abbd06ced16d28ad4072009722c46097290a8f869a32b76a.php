<?php

/* PanelBundle:panel:header.html.twig */
class __TwigTemplate_628526d065c2d4406ab951f670adef9df1799dec7641030044f8c58731288fb3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'header' => array($this, 'block_header'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8f7066ec2f776054a5408b229d6a0614d95e1461ea1b4b7cae2c274585121320 = $this->env->getExtension("native_profiler");
        $__internal_8f7066ec2f776054a5408b229d6a0614d95e1461ea1b4b7cae2c274585121320->enter($__internal_8f7066ec2f776054a5408b229d6a0614d95e1461ea1b4b7cae2c274585121320_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PanelBundle:panel:header.html.twig"));

        // line 1
        $this->displayBlock('header', $context, $blocks);
        
        $__internal_8f7066ec2f776054a5408b229d6a0614d95e1461ea1b4b7cae2c274585121320->leave($__internal_8f7066ec2f776054a5408b229d6a0614d95e1461ea1b4b7cae2c274585121320_prof);

    }

    public function block_header($context, array $blocks = array())
    {
        $__internal_addc9af25cedec2a27b514a38b4937fd017242b9a66d38f58d69f0957f08f9f7 = $this->env->getExtension("native_profiler");
        $__internal_addc9af25cedec2a27b514a38b4937fd017242b9a66d38f58d69f0957f08f9f7->enter($__internal_addc9af25cedec2a27b514a38b4937fd017242b9a66d38f58d69f0957f08f9f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 2
        echo "<header>
\t<div class=\"header-top\">
\t\t<ul class=\"colHeader\">
\t\t\t<li>
\t\t\t\t<div class=\"conteMenu\"><span><img src=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/panel/images/btnMenul.png"), "html", null, true);
        echo "\"></span>Menu</div>
\t\t\t</li>
\t\t\t<li><a href=\"#\" class=\"logo\"><img src=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/panel/images/logo.png"), "html", null, true);
        echo "\"></a></li>
\t\t\t<li></li>
\t\t\t<div class=\"clear\"></div>
\t\t</ul>
\t</div>
\t<div class=\"header-bot\">
\t\t<ul class=\"colHeaderBot\">
\t\t\t<li>Sales: 800-417-5660\tService: 800-417-5731</li>
\t\t\t<li>3300 Jamboree Road • Newport Beach, CA 92660</li>
\t\t\t<div class=\"clear\"></div>
\t\t</ul>
\t</div>
</header>
<div class=\"menuLateral\" style=\"top: -100%;\">
\t<div class=\"cerrarMenu\">
\t\t<div class=\"padding\">
\t\t\t<i class=\"fa fa-times\" aria-hidden=\"true\"></i><span>Cerrar</span>
\t\t</div>
\t</div>
\t<ul class=\"menu\">
\t\t<li class=\"menu_activo\"><a href=\"#\">inicio</a></li>
\t\t<li>
\t\t\t<a href=\"";
        // line 30
        echo $this->env->getExtension('routing')->getPath("panel_log_out");
        echo "\">Cerrar Sesión</a>
\t\t</li>
\t</ul>
</div>
";
        
        $__internal_addc9af25cedec2a27b514a38b4937fd017242b9a66d38f58d69f0957f08f9f7->leave($__internal_addc9af25cedec2a27b514a38b4937fd017242b9a66d38f58d69f0957f08f9f7_prof);

    }

    public function getTemplateName()
    {
        return "PanelBundle:panel:header.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  71 => 30,  46 => 8,  41 => 6,  35 => 2,  23 => 1,);
    }
}
/* {% block header %}*/
/* <header>*/
/* 	<div class="header-top">*/
/* 		<ul class="colHeader">*/
/* 			<li>*/
/* 				<div class="conteMenu"><span><img src="{{ asset('bundles/panel/images/btnMenul.png') }}"></span>Menu</div>*/
/* 			</li>*/
/* 			<li><a href="#" class="logo"><img src="{{ asset('bundles/panel/images/logo.png') }}"></a></li>*/
/* 			<li></li>*/
/* 			<div class="clear"></div>*/
/* 		</ul>*/
/* 	</div>*/
/* 	<div class="header-bot">*/
/* 		<ul class="colHeaderBot">*/
/* 			<li>Sales: 800-417-5660	Service: 800-417-5731</li>*/
/* 			<li>3300 Jamboree Road • Newport Beach, CA 92660</li>*/
/* 			<div class="clear"></div>*/
/* 		</ul>*/
/* 	</div>*/
/* </header>*/
/* <div class="menuLateral" style="top: -100%;">*/
/* 	<div class="cerrarMenu">*/
/* 		<div class="padding">*/
/* 			<i class="fa fa-times" aria-hidden="true"></i><span>Cerrar</span>*/
/* 		</div>*/
/* 	</div>*/
/* 	<ul class="menu">*/
/* 		<li class="menu_activo"><a href="#">inicio</a></li>*/
/* 		<li>*/
/* 			<a href="{{ path('panel_log_out') }}">Cerrar Sesión</a>*/
/* 		</li>*/
/* 	</ul>*/
/* </div>*/
/* {% endblock%}*/
