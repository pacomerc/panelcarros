<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        // panel_default_index
        if ($pathinfo === '/test') {
            return array (  '_controller' => 'PanelBundle\\Controller\\DefaultController::indexAction',  '_route' => 'panel_default_index',);
        }

        // homepanel
        if (rtrim($pathinfo, '/') === '/home') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepanel');
            }

            return array (  '_controller' => 'PanelBundle\\Controller\\HomeController::indexAction',  '_route' => 'homepanel',);
        }

        // jsonhomepanel
        if (rtrim($pathinfo, '/') === '/json-home') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'jsonhomepanel');
            }

            return array (  '_controller' => 'PanelBundle\\Controller\\JsonHomeController::indexAction',  '_route' => 'jsonhomepanel',);
        }

        // ajaxseccion
        if (rtrim($pathinfo, '/') === '/ajax') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'ajaxseccion');
            }

            return array (  '_controller' => 'PanelBundle\\Controller\\PrintCarsController::indexAction',  '_route' => 'ajaxseccion',);
        }

        // panel_sing_in
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'panel_sing_in');
            }

            return array (  '_controller' => 'PanelBundle\\Controller\\SessionController::indexAction',  '_route' => 'panel_sing_in',);
        }

        // panel_log_out
        if ($pathinfo === '/logout') {
            return array (  '_controller' => 'PanelBundle\\Controller\\SessionController::logoutAction',  '_route' => 'panel_log_out',);
        }

        // homepage1
        if ($pathinfo === '/otro') {
            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage1',);
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
