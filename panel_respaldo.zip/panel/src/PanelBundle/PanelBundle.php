<?php

namespace PanelBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PanelBundle extends Bundle
{
}
