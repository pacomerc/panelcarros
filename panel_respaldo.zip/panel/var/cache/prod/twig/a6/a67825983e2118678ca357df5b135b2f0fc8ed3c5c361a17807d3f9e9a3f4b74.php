<?php

/* PanelBundle:panel:home.html.twig */
class __TwigTemplate_10696204a95506209146bace5367d87a894f76df8d4c8d2cd0e9c91870911721 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("PanelBundle:panel:base.html.twig", "PanelBundle:panel:home.html.twig", 1);
        $this->blocks = array(
            'metas' => array($this, 'block_metas'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "PanelBundle:panel:base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9b5d3ceca1d6fa54ede2071e97dc3b91cbd909323fa5563e546e1c1d9e7bcc74 = $this->env->getExtension("native_profiler");
        $__internal_9b5d3ceca1d6fa54ede2071e97dc3b91cbd909323fa5563e546e1c1d9e7bcc74->enter($__internal_9b5d3ceca1d6fa54ede2071e97dc3b91cbd909323fa5563e546e1c1d9e7bcc74_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PanelBundle:panel:home.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9b5d3ceca1d6fa54ede2071e97dc3b91cbd909323fa5563e546e1c1d9e7bcc74->leave($__internal_9b5d3ceca1d6fa54ede2071e97dc3b91cbd909323fa5563e546e1c1d9e7bcc74_prof);

    }

    // line 3
    public function block_metas($context, array $blocks = array())
    {
        $__internal_616ce0e1f2be85356d3743996f3bb8612231f7ef15aaa61036a17a2a9f4b9658 = $this->env->getExtension("native_profiler");
        $__internal_616ce0e1f2be85356d3743996f3bb8612231f7ef15aaa61036a17a2a9f4b9658->enter($__internal_616ce0e1f2be85356d3743996f3bb8612231f7ef15aaa61036a17a2a9f4b9658_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "metas"));

        // line 4
        echo "<meta name=\"description\" content=\"panel excel\">
<meta name=\"keywords\" content=\"Panel\">
";
        
        $__internal_616ce0e1f2be85356d3743996f3bb8612231f7ef15aaa61036a17a2a9f4b9658->leave($__internal_616ce0e1f2be85356d3743996f3bb8612231f7ef15aaa61036a17a2a9f4b9658_prof);

    }

    // line 8
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_35c456a090a6fa8a73a375cc8fdbf7158fc811eb01c27440d582c1793ef8144a = $this->env->getExtension("native_profiler");
        $__internal_35c456a090a6fa8a73a375cc8fdbf7158fc811eb01c27440d582c1793ef8144a->enter($__internal_35c456a090a6fa8a73a375cc8fdbf7158fc811eb01c27440d582c1793ef8144a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 9
        echo "\t
\t<link href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/panel/css/styles.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
";
        
        $__internal_35c456a090a6fa8a73a375cc8fdbf7158fc811eb01c27440d582c1793ef8144a->leave($__internal_35c456a090a6fa8a73a375cc8fdbf7158fc811eb01c27440d582c1793ef8144a_prof);

    }

    // line 14
    public function block_body($context, array $blocks = array())
    {
        $__internal_67b677ff85b710ef5b610449301bf603483a85b8e62beaab05f29555b585d3bb = $this->env->getExtension("native_profiler");
        $__internal_67b677ff85b710ef5b610449301bf603483a85b8e62beaab05f29555b585d3bb->enter($__internal_67b677ff85b710ef5b610449301bf603483a85b8e62beaab05f29555b585d3bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 15
        echo "<!-- form1 -->
";
        // line 16
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("id" => "form-seleccionar")));
        echo "
";
        // line 17
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
";
        // line 18
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
<!-- END form1 -->
";
        
        $__internal_67b677ff85b710ef5b610449301bf603483a85b8e62beaab05f29555b585d3bb->leave($__internal_67b677ff85b710ef5b610449301bf603483a85b8e62beaab05f29555b585d3bb_prof);

    }

    // line 22
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_b6e112b21754e57e0a335473408af3d8d49ad48ce7dc35141e230b071d925c3a = $this->env->getExtension("native_profiler");
        $__internal_b6e112b21754e57e0a335473408af3d8d49ad48ce7dc35141e230b071d925c3a->enter($__internal_b6e112b21754e57e0a335473408af3d8d49ad48ce7dc35141e230b071d925c3a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 23
        echo "<script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/panel/js/jquery-2.1.4.min.js"), "html", null, true);
        echo "\" ></script>
<script type=\"text/javascript\" src=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/panel/js/funciones.js"), "html", null, true);
        echo "\" ></script>
";
        
        $__internal_b6e112b21754e57e0a335473408af3d8d49ad48ce7dc35141e230b071d925c3a->leave($__internal_b6e112b21754e57e0a335473408af3d8d49ad48ce7dc35141e230b071d925c3a_prof);

    }

    public function getTemplateName()
    {
        return "PanelBundle:panel:home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  108 => 24,  103 => 23,  97 => 22,  87 => 18,  83 => 17,  79 => 16,  76 => 15,  70 => 14,  61 => 10,  58 => 9,  52 => 8,  43 => 4,  37 => 3,  11 => 1,);
    }
}
/* {% extends 'PanelBundle:panel:base.html.twig' %}*/
/* */
/* {% block metas %}*/
/* <meta name="description" content="panel excel">*/
/* <meta name="keywords" content="Panel">*/
/* {% endblock %}*/
/* */
/* {% block stylesheets %}*/
/* 	*/
/* 	<link href="{{ asset('bundles/panel/css/styles.css') }}" rel="stylesheet" />*/
/* {% endblock %}*/
/* */
/* */
/* {% block body %}*/
/* <!-- form1 -->*/
/* {{ form_start(form, {'attr': {'id': 'form-seleccionar'}})  }}*/
/* {{ form_widget(form) }}*/
/* {{ form_end(form) }}*/
/* <!-- END form1 -->*/
/* {% endblock %}*/
/* */
/* {% block scripts %}*/
/* <script type="text/javascript" src="{{ asset('bundles/panel/js/jquery-2.1.4.min.js') }}" ></script>*/
/* <script type="text/javascript" src="{{ asset('bundles/panel/js/funciones.js') }}" ></script>*/
/* {% endblock %}*/
/* */
/* */
/* */
/* */
/* */
