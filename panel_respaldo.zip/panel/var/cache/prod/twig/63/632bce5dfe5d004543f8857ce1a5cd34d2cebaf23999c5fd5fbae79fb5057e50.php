<?php

/* PanelBundle:panel:index.html.twig */
class __TwigTemplate_9ceea66be991d81d8ed0fe05dff7397b1d0ba112a1e7298342662b3a09910f2b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("PanelBundle:panel:base.html.twig", "PanelBundle:panel:index.html.twig", 2);
        $this->blocks = array(
            'metas' => array($this, 'block_metas'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "PanelBundle:panel:base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4ac5c75fbc42d287dabb0ec287dd0bac1fe14cb0a53344ce8fa3bb3ca5d2e67d = $this->env->getExtension("native_profiler");
        $__internal_4ac5c75fbc42d287dabb0ec287dd0bac1fe14cb0a53344ce8fa3bb3ca5d2e67d->enter($__internal_4ac5c75fbc42d287dabb0ec287dd0bac1fe14cb0a53344ce8fa3bb3ca5d2e67d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PanelBundle:panel:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4ac5c75fbc42d287dabb0ec287dd0bac1fe14cb0a53344ce8fa3bb3ca5d2e67d->leave($__internal_4ac5c75fbc42d287dabb0ec287dd0bac1fe14cb0a53344ce8fa3bb3ca5d2e67d_prof);

    }

    // line 4
    public function block_metas($context, array $blocks = array())
    {
        $__internal_10754e05e5e654f1461cd212ee5cd581498949145234944d88ef348f9b8bc5ca = $this->env->getExtension("native_profiler");
        $__internal_10754e05e5e654f1461cd212ee5cd581498949145234944d88ef348f9b8bc5ca->enter($__internal_10754e05e5e654f1461cd212ee5cd581498949145234944d88ef348f9b8bc5ca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "metas"));

        // line 5
        echo "<meta name=\"description\" content=\"panel excel\">
<meta name=\"keywords\" content=\"Panel\">
";
        
        $__internal_10754e05e5e654f1461cd212ee5cd581498949145234944d88ef348f9b8bc5ca->leave($__internal_10754e05e5e654f1461cd212ee5cd581498949145234944d88ef348f9b8bc5ca_prof);

    }

    public function getTemplateName()
    {
        return "PanelBundle:panel:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 5,  34 => 4,  11 => 2,);
    }
}
/* {# PanelBundle/Resources/views/panel/index.html.twig #}*/
/* {% extends 'PanelBundle:panel:base.html.twig' %}*/
/* */
/* {% block metas %}*/
/* <meta name="description" content="panel excel">*/
/* <meta name="keywords" content="Panel">*/
/* {% endblock %}*/
