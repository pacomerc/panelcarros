<?php

/* PanelBundle:panel:index.html.twig */
class __TwigTemplate_7aef4d27ce1d1a9149c9fee6827c306b473143b05543781c2ef56d7b9f7f3050 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "PanelBundle:panel:index.html.twig", 2);
        $this->blocks = array(
            'metas' => array($this, 'block_metas'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_metas($context, array $blocks = array())
    {
        // line 6
        echo "<meta name=\"description\" content=\"En Ensamble contribuimos a mejorar la calidad de vida a través de nuestra creatividad, generando desarrollos inmobiliarios de vanguardia y modernidad.\">
        <meta name=\"keywords\" content=\"Espacios de vanguardia, Constructora, espacios modernos\">
";
    }

    public function getTemplateName()
    {
        return "PanelBundle:panel:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 6,  28 => 5,  11 => 2,);
    }
}
/* {# PanelBundle/Resources/views/panel/index.html.twig #}*/
/* {% extends 'base.html.twig' %}*/
/* */
/* */
/* {% block metas %}*/
/* <meta name="description" content="En Ensamble contribuimos a mejorar la calidad de vida a través de nuestra creatividad, generando desarrollos inmobiliarios de vanguardia y modernidad.">*/
/*         <meta name="keywords" content="Espacios de vanguardia, Constructora, espacios modernos">*/
/* {% endblock %}*/
